<?php

/*
+---------------------------------------------------------------------------+
| Revive Adserver                                                           |
| http://www.revive-adserver.com                                            |
|                                                                           |
| Copyright: See the COPYRIGHT.txt file.                                    |
| License: GPLv2 or later, see the LICENSE.txt file.                        |
+---------------------------------------------------------------------------+
*/

$words = array(
    'Local Mode Tag' => 'Local Mode Tag',
    'Allow Local Mode Tags' => 'Allow Local Mode Tags',

    'Assign the $phpAds_raw[\'html\'] variable to your template' => 'Assign the $phpAds_raw[\'html\'] variable to your template',
    
    'Third Party Comment' => '',
    'Cache Buster Comment' => '',
    'SSL Backup Comment' => '',
    'SSL Delivery Comment' => '',
    'Comment' => '',
);

?>